﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VP_PROJECT
{
    public partial class SplashScreen : Form
    {
        
        public SplashScreen()
        {
            InitializeComponent();
        }

        private void UserNameLabel_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.progressBar.Increment(1);
            if (progressBar.Value == 50)
            {
                timer1.Enabled = false;
                this.Hide();
                MainScreen ob = new MainScreen();
                ob.Show();
            }
        }

        private void SplashScreen_Load(object sender, EventArgs e)
        {
            this.timer1.Start();
            progressBar.Visible = true;
            
        }

        private void progressBar_Click(object sender, EventArgs e)
        {

        }
    }
}
