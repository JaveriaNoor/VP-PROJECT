﻿namespace VP_PROJECT
{
    partial class ClassName
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClassName));
            this.txtClassName = new System.Windows.Forms.TextBox();
            this.panelOfOperationsandProperties = new System.Windows.Forms.Panel();
            this.panelOpertns = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btnOprtn = new MetroFramework.Controls.MetroButton();
            this.tbOprtnNam = new MetroFramework.Controls.MetroTextBox();
            this.lbRtrnTypOprtn = new System.Windows.Forms.Label();
            this.lbNamOpertn = new System.Windows.Forms.Label();
            this.cmbOprtnTyp = new MetroFramework.Controls.MetroComboBox();
            this.filingButton = new MetroFramework.Controls.MetroButton();
            this.pnlDataMembers = new System.Windows.Forms.Panel();
            this.lbModDm = new System.Windows.Forms.Label();
            this.btnDataMembers = new MetroFramework.Controls.MetroButton();
            this.txtDataMemberName = new MetroFramework.Controls.MetroTextBox();
            this.lbDataTypeProperties = new System.Windows.Forms.Label();
            this.lbNamDataTyp = new System.Windows.Forms.Label();
            this.cmbDataType = new MetroFramework.Controls.MetroComboBox();
            this.tsMethods = new System.Windows.Forms.ToolStrip();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.AtributesBtn = new System.Windows.Forms.ToolStripButton();
            this.txtMethods = new System.Windows.Forms.RichTextBox();
            this.txtAttributes = new System.Windows.Forms.RichTextBox();
            this.lbModifiers = new System.Windows.Forms.Label();
            this.panelOfOperationsandProperties.SuspendLayout();
            this.panelOpertns.SuspendLayout();
            this.pnlDataMembers.SuspendLayout();
            this.tsMethods.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtClassName
            // 
            this.txtClassName.BackColor = System.Drawing.Color.Navy;
            this.txtClassName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtClassName.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtClassName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtClassName.ForeColor = System.Drawing.Color.White;
            this.txtClassName.Location = new System.Drawing.Point(0, 12);
            this.txtClassName.Name = "txtClassName";
            this.txtClassName.ReadOnly = true;
            this.txtClassName.Size = new System.Drawing.Size(243, 19);
            this.txtClassName.TabIndex = 3;
            this.txtClassName.Text = "Name";
            this.txtClassName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtClassName.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.txtClassName.DoubleClick += new System.EventHandler(this.textBox1_DoubleClick);
            this.txtClassName.MouseLeave += new System.EventHandler(this.textBox1_MouseLeave);
            this.txtClassName.Resize += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // panelOfOperationsandProperties
            // 
            this.panelOfOperationsandProperties.Controls.Add(this.panelOpertns);
            this.panelOfOperationsandProperties.Controls.Add(this.filingButton);
            this.panelOfOperationsandProperties.Controls.Add(this.pnlDataMembers);
            this.panelOfOperationsandProperties.Controls.Add(this.tsMethods);
            this.panelOfOperationsandProperties.Controls.Add(this.toolStrip1);
            this.panelOfOperationsandProperties.Controls.Add(this.txtMethods);
            this.panelOfOperationsandProperties.Controls.Add(this.txtAttributes);
            this.panelOfOperationsandProperties.Location = new System.Drawing.Point(0, 37);
            this.panelOfOperationsandProperties.Name = "panelOfOperationsandProperties";
            this.panelOfOperationsandProperties.Size = new System.Drawing.Size(243, 380);
            this.panelOfOperationsandProperties.TabIndex = 4;
            this.panelOfOperationsandProperties.Paint += new System.Windows.Forms.PaintEventHandler(this.panelOfOperationsandProperties_Paint);
            // 
            // panelOpertns
            // 
            this.panelOpertns.Controls.Add(this.label3);
            this.panelOpertns.Controls.Add(this.btnOprtn);
            this.panelOpertns.Controls.Add(this.tbOprtnNam);
            this.panelOpertns.Controls.Add(this.lbRtrnTypOprtn);
            this.panelOpertns.Controls.Add(this.lbNamOpertn);
            this.panelOpertns.Controls.Add(this.cmbOprtnTyp);
            this.panelOpertns.Location = new System.Drawing.Point(111, 204);
            this.panelOpertns.Name = "panelOpertns";
            this.panelOpertns.Size = new System.Drawing.Size(129, 158);
            this.panelOpertns.TabIndex = 9;
            this.panelOpertns.Visible = false;
            this.panelOpertns.Paint += new System.Windows.Forms.PaintEventHandler(this.panelOpertns_Paint);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(110, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(19, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "+";
            // 
            // btnOprtn
            // 
            this.btnOprtn.Location = new System.Drawing.Point(90, 128);
            this.btnOprtn.Name = "btnOprtn";
            this.btnOprtn.Size = new System.Drawing.Size(39, 23);
            this.btnOprtn.TabIndex = 5;
            this.btnOprtn.Text = "Done";
            this.btnOprtn.UseSelectable = true;
            this.btnOprtn.Click += new System.EventHandler(this.btnOprtn_Click);
            // 
            // tbOprtnNam
            // 
            this.tbOprtnNam.Lines = new string[0];
            this.tbOprtnNam.Location = new System.Drawing.Point(3, 39);
            this.tbOprtnNam.MaxLength = 32767;
            this.tbOprtnNam.Name = "tbOprtnNam";
            this.tbOprtnNam.PasswordChar = '\0';
            this.tbOprtnNam.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbOprtnNam.SelectedText = "";
            this.tbOprtnNam.Size = new System.Drawing.Size(126, 23);
            this.tbOprtnNam.TabIndex = 4;
            this.tbOprtnNam.UseSelectable = true;
            // 
            // lbRtrnTypOprtn
            // 
            this.lbRtrnTypOprtn.AutoSize = true;
            this.lbRtrnTypOprtn.ForeColor = System.Drawing.Color.White;
            this.lbRtrnTypOprtn.Location = new System.Drawing.Point(3, 74);
            this.lbRtrnTypOprtn.Name = "lbRtrnTypOprtn";
            this.lbRtrnTypOprtn.Size = new System.Drawing.Size(69, 13);
            this.lbRtrnTypOprtn.TabIndex = 3;
            this.lbRtrnTypOprtn.Text = "Return Type:";
            // 
            // lbNamOpertn
            // 
            this.lbNamOpertn.AutoSize = true;
            this.lbNamOpertn.ForeColor = System.Drawing.Color.White;
            this.lbNamOpertn.Location = new System.Drawing.Point(4, 20);
            this.lbNamOpertn.Name = "lbNamOpertn";
            this.lbNamOpertn.Size = new System.Drawing.Size(38, 13);
            this.lbNamOpertn.TabIndex = 3;
            this.lbNamOpertn.Text = "Name:";
            // 
            // cmbOprtnTyp
            // 
            this.cmbOprtnTyp.FormattingEnabled = true;
            this.cmbOprtnTyp.ItemHeight = 23;
            this.cmbOprtnTyp.Items.AddRange(new object[] {
            "int",
            "void",
            "float",
            "decimal",
            "double",
            "char",
            "string"});
            this.cmbOprtnTyp.Location = new System.Drawing.Point(3, 93);
            this.cmbOprtnTyp.Name = "cmbOprtnTyp";
            this.cmbOprtnTyp.Size = new System.Drawing.Size(126, 29);
            this.cmbOprtnTyp.TabIndex = 1;
            this.cmbOprtnTyp.UseSelectable = true;
            // 
            // filingButton
            // 
            this.filingButton.Location = new System.Drawing.Point(0, 362);
            this.filingButton.Name = "filingButton";
            this.filingButton.Size = new System.Drawing.Size(241, 20);
            this.filingButton.TabIndex = 5;
            this.filingButton.Text = "Generate Code";
            this.filingButton.UseSelectable = true;
            this.filingButton.Click += new System.EventHandler(this.filingButton_Click);
            // 
            // pnlDataMembers
            // 
            this.pnlDataMembers.Controls.Add(this.lbModDm);
            this.pnlDataMembers.Controls.Add(this.btnDataMembers);
            this.pnlDataMembers.Controls.Add(this.txtDataMemberName);
            this.pnlDataMembers.Controls.Add(this.lbDataTypeProperties);
            this.pnlDataMembers.Controls.Add(this.lbNamDataTyp);
            this.pnlDataMembers.Controls.Add(this.cmbDataType);
            this.pnlDataMembers.Location = new System.Drawing.Point(111, 24);
            this.pnlDataMembers.Name = "pnlDataMembers";
            this.pnlDataMembers.Size = new System.Drawing.Size(133, 158);
            this.pnlDataMembers.TabIndex = 8;
            this.pnlDataMembers.Visible = false;
            // 
            // lbModDm
            // 
            this.lbModDm.AutoSize = true;
            this.lbModDm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbModDm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbModDm.ForeColor = System.Drawing.Color.White;
            this.lbModDm.Location = new System.Drawing.Point(110, 15);
            this.lbModDm.Name = "lbModDm";
            this.lbModDm.Size = new System.Drawing.Size(19, 20);
            this.lbModDm.TabIndex = 7;
            this.lbModDm.Text = "+";
            // 
            // btnDataMembers
            // 
            this.btnDataMembers.Location = new System.Drawing.Point(90, 129);
            this.btnDataMembers.Name = "btnDataMembers";
            this.btnDataMembers.Size = new System.Drawing.Size(39, 23);
            this.btnDataMembers.TabIndex = 5;
            this.btnDataMembers.Text = "Done";
            this.btnDataMembers.UseSelectable = true;
            this.btnDataMembers.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // txtDataMemberName
            // 
            this.txtDataMemberName.Lines = new string[0];
            this.txtDataMemberName.Location = new System.Drawing.Point(3, 37);
            this.txtDataMemberName.MaxLength = 32767;
            this.txtDataMemberName.Name = "txtDataMemberName";
            this.txtDataMemberName.PasswordChar = '\0';
            this.txtDataMemberName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtDataMemberName.SelectedText = "";
            this.txtDataMemberName.Size = new System.Drawing.Size(126, 23);
            this.txtDataMemberName.TabIndex = 4;
            this.txtDataMemberName.UseSelectable = true;
            this.txtDataMemberName.TextChanged += new System.EventHandler(this.txtDataMemberName_TextChanged);
            this.txtDataMemberName.Click += new System.EventHandler(this.txtDataMemberName_Click);
            // 
            // lbDataTypeProperties
            // 
            this.lbDataTypeProperties.AutoSize = true;
            this.lbDataTypeProperties.ForeColor = System.Drawing.Color.White;
            this.lbDataTypeProperties.Location = new System.Drawing.Point(4, 73);
            this.lbDataTypeProperties.Name = "lbDataTypeProperties";
            this.lbDataTypeProperties.Size = new System.Drawing.Size(60, 13);
            this.lbDataTypeProperties.TabIndex = 3;
            this.lbDataTypeProperties.Text = "Data Type:";
            // 
            // lbNamDataTyp
            // 
            this.lbNamDataTyp.AutoSize = true;
            this.lbNamDataTyp.ForeColor = System.Drawing.Color.White;
            this.lbNamDataTyp.Location = new System.Drawing.Point(4, 19);
            this.lbNamDataTyp.Name = "lbNamDataTyp";
            this.lbNamDataTyp.Size = new System.Drawing.Size(38, 13);
            this.lbNamDataTyp.TabIndex = 3;
            this.lbNamDataTyp.Text = "Name:";
            // 
            // cmbDataType
            // 
            this.cmbDataType.FormattingEnabled = true;
            this.cmbDataType.ItemHeight = 23;
            this.cmbDataType.Items.AddRange(new object[] {
            "int",
            "float",
            "decimal",
            "double",
            "char",
            "string"});
            this.cmbDataType.Location = new System.Drawing.Point(3, 95);
            this.cmbDataType.Name = "cmbDataType";
            this.cmbDataType.Size = new System.Drawing.Size(126, 29);
            this.cmbDataType.TabIndex = 1;
            this.cmbDataType.UseSelectable = true;
            // 
            // tsMethods
            // 
            this.tsMethods.AutoSize = false;
            this.tsMethods.Dock = System.Windows.Forms.DockStyle.None;
            this.tsMethods.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton4,
            this.toolStripSeparator4,
            this.toolStripLabel2,
            this.toolStripSeparator2,
            this.toolStripButton5});
            this.tsMethods.Location = new System.Drawing.Point(0, 181);
            this.tsMethods.Name = "tsMethods";
            this.tsMethods.Size = new System.Drawing.Size(243, 25);
            this.tsMethods.TabIndex = 7;
            this.tsMethods.Text = "toolStrip2";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton4.Text = "toolStripButton1";
            this.toolStripButton4.ToolTipText = "Minimize Methods Area";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(54, 22);
            this.toolStripLabel2.Text = "Methods";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton5.Text = "toolStripButton1";
            this.toolStripButton5.ToolTipText = "Add Methods";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripSeparator3,
            this.toolStripLabel1,
            this.toolStripSeparator1,
            this.AtributesBtn});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(243, 25);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.ToolTipText = "Minimize Data Member Area";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.AutoSize = false;
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(100, 22);
            this.toolStripLabel1.Text = "Data Members";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // AtributesBtn
            // 
            this.AtributesBtn.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.AtributesBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.AtributesBtn.Image = ((System.Drawing.Image)(resources.GetObject("AtributesBtn.Image")));
            this.AtributesBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AtributesBtn.Name = "AtributesBtn";
            this.AtributesBtn.Size = new System.Drawing.Size(23, 22);
            this.AtributesBtn.Text = "toolStripButton1";
            this.AtributesBtn.ToolTipText = "Add Attributes";
            this.AtributesBtn.Click += new System.EventHandler(this.AtributesBtn_Click);
            // 
            // txtMethods
            // 
            this.txtMethods.Location = new System.Drawing.Point(0, 204);
            this.txtMethods.Name = "txtMethods";
            this.txtMethods.Size = new System.Drawing.Size(243, 158);
            this.txtMethods.TabIndex = 2;
            this.txtMethods.Text = "";
            this.txtMethods.Click += new System.EventHandler(this.txtAttributes_Click);
            // 
            // txtAttributes
            // 
            this.txtAttributes.BackColor = System.Drawing.Color.White;
            this.txtAttributes.Location = new System.Drawing.Point(0, 24);
            this.txtAttributes.Name = "txtAttributes";
            this.txtAttributes.ReadOnly = true;
            this.txtAttributes.Size = new System.Drawing.Size(243, 158);
            this.txtAttributes.TabIndex = 0;
            this.txtAttributes.Text = "";
            this.txtAttributes.Click += new System.EventHandler(this.txtAttributes_Click);
            this.txtAttributes.TextChanged += new System.EventHandler(this.txtAttributes_TextChanged);
            // 
            // lbModifiers
            // 
            this.lbModifiers.AutoSize = true;
            this.lbModifiers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbModifiers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbModifiers.ForeColor = System.Drawing.Color.White;
            this.lbModifiers.Location = new System.Drawing.Point(74, 11);
            this.lbModifiers.Name = "lbModifiers";
            this.lbModifiers.Size = new System.Drawing.Size(19, 20);
            this.lbModifiers.TabIndex = 6;
            this.lbModifiers.Text = "+";
            // 
            // ClassName
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Navy;
            this.ClientSize = new System.Drawing.Size(241, 418);
            this.ControlBox = false;
            this.Controls.Add(this.lbModifiers);
            this.Controls.Add(this.panelOfOperationsandProperties);
            this.Controls.Add(this.txtClassName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ClassName";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Class";
            this.Load += new System.EventHandler(this.ClassName_Load);
            this.panelOfOperationsandProperties.ResumeLayout(false);
            this.panelOfOperationsandProperties.PerformLayout();
            this.panelOpertns.ResumeLayout(false);
            this.panelOpertns.PerformLayout();
            this.pnlDataMembers.ResumeLayout(false);
            this.pnlDataMembers.PerformLayout();
            this.tsMethods.ResumeLayout(false);
            this.tsMethods.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtClassName;
        private System.Windows.Forms.Panel panelOfOperationsandProperties;
        private System.Windows.Forms.RichTextBox txtMethods;
        private System.Windows.Forms.RichTextBox txtAttributes;
        private MetroFramework.Controls.MetroButton filingButton;
        private System.Windows.Forms.Panel pnlDataMembers;
        private System.Windows.Forms.ToolStrip tsMethods;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private MetroFramework.Controls.MetroComboBox cmbDataType;
        private System.Windows.Forms.Label lbDataTypeProperties;
        private System.Windows.Forms.Label lbNamDataTyp;
        private System.Windows.Forms.ToolStripButton AtributesBtn;
        private MetroFramework.Controls.MetroTextBox txtDataMemberName;
        private MetroFramework.Controls.MetroButton btnDataMembers;
        private System.Windows.Forms.Label lbModifiers;
        private System.Windows.Forms.Panel panelOpertns;
        private System.Windows.Forms.Label label3;
        private MetroFramework.Controls.MetroButton btnOprtn;
        private MetroFramework.Controls.MetroTextBox tbOprtnNam;
        private System.Windows.Forms.Label lbRtrnTypOprtn;
        private System.Windows.Forms.Label lbNamOpertn;
        private MetroFramework.Controls.MetroComboBox cmbOprtnTyp;
        private System.Windows.Forms.Label lbModDm;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;


    }
}