﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace VP_PROJECT
{
    public partial class ClassName : Form
    {
        bool isAttributePanelActive = false;
        bool isMethodPanelActive = false;
        bool isMembersActive = true;
        string[] attributes = new String[100];
        int attributesPosition = 0;
        string[] methods = new string[100];
        int methodsPosition = 0;

        //ClassName cn;
        private bool _dragging = false;
        private Point _offset;
        private Point _start_point = new Point(0, 0);

        public ClassName()
        {
            InitializeComponent();
           // cn = new ClassName();
        }

        // code for drag and drop form without control box 
        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if (m.Msg == WM_NCHITTEST)
                m.Result = (IntPtr)(HT_CAPTION);
        }

        private const int WM_NCHITTEST = 0x84;
        private const int HT_CLIENT = 0x1;
        private const int HT_CAPTION = 0x2;

        public String gettingTextFromTextBox()
        {
            String textOfRichTextBox =txtAttributes.Text;
            return textOfRichTextBox;
        }
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void ClassName_Load(object sender, EventArgs e)
        {
            ClassName cn = new ClassName();
            if (cn.Text == "<<p>>")
            {
                panelOfOperationsandProperties.Visible = false;

            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            TextBox tb = new TextBox();
            tb.Width = tb.Text.Length;


        }


        private void textBox1_DoubleClick(object sender, EventArgs e)
        {
            txtClassName.ReadOnly = false;
                //= false;

        }

        private void textBox1_MouseLeave(object sender, EventArgs e)
        {
            txtClassName.ReadOnly = true;
        }

        private void filingButton_Click(object sender, EventArgs e)
        {
            try
            {
                     string className = txtClassName.Text + ".cs";
                     string classText = "public class " + txtClassName.Text + " \n{\n";
                     string attrib = "";
                     string method = "";
                     for (int i = 0; i < attributes.Length; i++)
                     {
                         if (attributes[i]!=null)
                         {
                             attrib += attributes[i] + "\n";
                         }
                     }
                     for (int i = 0; i < methods.Length; i++)
                     {
                         if (methods[i]!=null)
                         {
                             // public text will be made dynamic soon
                             method +="\n" + "public " + methods[i] + "\n"+"{\n\n}";
                         }
                     }
                       
                    string classEnd = "\n}";
                    string AllData = classText + attrib + method + classEnd;
                    System.IO.File.WriteAllText("F:/JavPro/"+className,AllData);
                    MessageBox.Show("Class Code is Generated","Info",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    
            }
            catch (Exception err)
            {
                
                MessageBox.Show(err.Message);
            }  
        }

        private void AtributesBtn_Click(object sender, EventArgs e)
        {
            if (isAttributePanelActive==false)
            {
                pnlDataMembers.Visible = true;
                isAttributePanelActive = true;
            }
            else
                if (isAttributePanelActive==true)
                {
                    pnlDataMembers.Visible = false;
                    isAttributePanelActive = false;
                }
            
            
        }

        private void txtDataMemberName_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtDataMemberName_Click(object sender, EventArgs e)
        {

        }
        

        private void metroButton1_Click(object sender, EventArgs e)
        {
            if (txtDataMemberName.Text=="")
            {
                MessageBox.Show("Please provide variable name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    
            }else
                if (cmbDataType.Text=="")
                {
                    MessageBox.Show("Please provide data type for variables", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (txtAttributes.Text != "")
                    {
                        txtAttributes.AppendText("\n");
                    }
                    txtAttributes.AppendText(txtDataMemberName.Text + ":" + cmbDataType.Text);
                    attributes[attributesPosition] = cmbDataType.Text + " " + txtDataMemberName.Text + ";";
                    attributesPosition++;

                    //clear textbox 
                    txtDataMemberName.Text = "";
                }
        }

        private void panelOfOperationsandProperties_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelOpertns_Paint(object sender, PaintEventArgs e)
        {

        }

        private void toolStripButton3_MouseDown(object sender, MouseEventArgs e)
        {
            
        }

        private void toolStripButton3_MouseUp(object sender, MouseEventArgs e)
        {
           
        }

        private void toolStripButton3_MouseMove(object sender, MouseEventArgs e)
        {
       
        }

        private void txtAttributes_TextChanged(object sender, EventArgs e)
        {

        }

       public  void HideAttributesPanel(Panel pnl)
       {
           pnl.Visible = false;
           isAttributePanelActive = false;
       }

       private void txtAttributes_Click(object sender, EventArgs e)
       {
           HideAttributesPanel(pnlDataMembers);
           HideAttributesPanel(panelOpertns);
       }

       private void toolStripButton1_Click(object sender, EventArgs e)
       {
           if (isMembersActive==true)
           {
               txtAttributes.Visible = false;
               isMembersActive = false;
               tsMethods.Location = new Point(0, 24);
               txtMethods.Location = new Point(0, 43);
               filingButton.Location = new Point(0, 183);
               this.Size = new Size(241, 203);
               isMembersActive = false;
           }
           else
               if (isMembersActive == false)
               {
                   txtAttributes.Visible = true;
                   isMembersActive = true;
                   tsMethods.Location = new Point(0, 181);
                   txtMethods.Location = new Point(0, 204);
                   filingButton.Location = new Point(0, 362);
                   this.Size = new Size(241, 418);
                   isMembersActive = true;
               }
       }

       private void toolStripButton5_Click(object sender, EventArgs e)
       {
           if (isMethodPanelActive == false)
           {
               panelOpertns.Visible = true;
               isMethodPanelActive = true;
           }
           else
               if (isMethodPanelActive == true)
               {
                   panelOpertns.Visible = false;
                   isMethodPanelActive = false;
               }
       }

       private void btnOprtn_Click(object sender, EventArgs e)
       {
           
           if (tbOprtnNam.Text=="")
            {
                MessageBox.Show("Please provide method name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    
            }else
               if (cmbOprtnTyp.Text == "")
               {
                   MessageBox.Show("Please provide return type for method", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
               }
               else
               {
                   if (txtMethods.Text != "")
                   {
                       txtMethods.AppendText("\n");
                   }
                   txtMethods.AppendText(tbOprtnNam.Text + ":" + cmbOprtnTyp.Text);
                   methods[methodsPosition] = cmbOprtnTyp.Text + " " + tbOprtnNam.Text + "()";
                   methodsPosition++;

                   //clear textbox 
                   tbOprtnNam.Text = "";
               }
       }

     
    }
}
