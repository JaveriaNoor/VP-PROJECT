﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VP_PROJECT
{
    public partial class InerfaceForm : Form
    {
        public InerfaceForm()
        {
            InitializeComponent();
        }
    }
}
