﻿namespace VP_PROJECT
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanelClasses = new MetroFramework.Controls.MetroPanel();
            this.EnumTile = new MetroFramework.Controls.MetroTile();
            this.PackageTile = new MetroFramework.Controls.MetroTile();
            this.ObjectTile = new MetroFramework.Controls.MetroTile();
            this.StereotypeTile = new MetroFramework.Controls.MetroTile();
            this.DataTypeTile = new MetroFramework.Controls.MetroTile();
            this.interfaceTile = new MetroFramework.Controls.MetroTile();
            this.PrimitiveTile = new MetroFramework.Controls.MetroTile();
            this.SimpleClasTile = new MetroFramework.Controls.MetroTile();
            this.panel1 = new System.Windows.Forms.Panel();
            this.metroTile18 = new MetroFramework.Controls.MetroTile();
            this.metroTile17 = new MetroFramework.Controls.MetroTile();
            this.metroTile16 = new MetroFramework.Controls.MetroTile();
            this.metroTile15 = new MetroFramework.Controls.MetroTile();
            this.metroTile14 = new MetroFramework.Controls.MetroTile();
            this.metroTile13 = new MetroFramework.Controls.MetroTile();
            this.metroTile11 = new MetroFramework.Controls.MetroTile();
            this.metroPanelClasses.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanelClasses
            // 
            this.metroPanelClasses.BackColor = System.Drawing.Color.Silver;
            this.metroPanelClasses.Controls.Add(this.EnumTile);
            this.metroPanelClasses.Controls.Add(this.PackageTile);
            this.metroPanelClasses.Controls.Add(this.ObjectTile);
            this.metroPanelClasses.Controls.Add(this.StereotypeTile);
            this.metroPanelClasses.Controls.Add(this.DataTypeTile);
            this.metroPanelClasses.Controls.Add(this.interfaceTile);
            this.metroPanelClasses.Controls.Add(this.PrimitiveTile);
            this.metroPanelClasses.Controls.Add(this.SimpleClasTile);
            this.metroPanelClasses.Dock = System.Windows.Forms.DockStyle.Left;
            this.metroPanelClasses.HorizontalScrollbarBarColor = true;
            this.metroPanelClasses.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanelClasses.HorizontalScrollbarSize = 10;
            this.metroPanelClasses.Location = new System.Drawing.Point(0, 0);
            this.metroPanelClasses.Name = "metroPanelClasses";
            this.metroPanelClasses.Size = new System.Drawing.Size(253, 650);
            this.metroPanelClasses.TabIndex = 5;
            this.metroPanelClasses.VerticalScrollbarBarColor = true;
            this.metroPanelClasses.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanelClasses.VerticalScrollbarSize = 10;
            // 
            // EnumTile
            // 
            this.EnumTile.ActiveControl = null;
            this.EnumTile.Location = new System.Drawing.Point(129, 111);
            this.EnumTile.Name = "EnumTile";
            this.EnumTile.Size = new System.Drawing.Size(120, 100);
            this.EnumTile.TabIndex = 10;
            this.EnumTile.Text = "Enumeration";
            this.EnumTile.UseSelectable = true;
            this.EnumTile.Click += new System.EventHandler(this.EnumTile_Click);
            // 
            // PackageTile
            // 
            this.PackageTile.ActiveControl = null;
            this.PackageTile.Location = new System.Drawing.Point(129, 5);
            this.PackageTile.Name = "PackageTile";
            this.PackageTile.Size = new System.Drawing.Size(120, 100);
            this.PackageTile.TabIndex = 9;
            this.PackageTile.Text = "Package";
            this.PackageTile.UseSelectable = true;
            this.PackageTile.Click += new System.EventHandler(this.metroTile2_Click);
            // 
            // ObjectTile
            // 
            this.ObjectTile.ActiveControl = null;
            this.ObjectTile.Location = new System.Drawing.Point(129, 322);
            this.ObjectTile.Name = "ObjectTile";
            this.ObjectTile.Size = new System.Drawing.Size(120, 100);
            this.ObjectTile.TabIndex = 7;
            this.ObjectTile.Text = "Object";
            this.ObjectTile.UseSelectable = true;
            this.ObjectTile.Click += new System.EventHandler(this.ObjectTile_Click);
            // 
            // StereotypeTile
            // 
            this.StereotypeTile.ActiveControl = null;
            this.StereotypeTile.Location = new System.Drawing.Point(4, 322);
            this.StereotypeTile.Name = "StereotypeTile";
            this.StereotypeTile.Size = new System.Drawing.Size(120, 100);
            this.StereotypeTile.TabIndex = 6;
            this.StereotypeTile.Text = "Stereotype";
            this.StereotypeTile.UseSelectable = true;
            this.StereotypeTile.Click += new System.EventHandler(this.StereotypeTile_Click);
            // 
            // DataTypeTile
            // 
            this.DataTypeTile.ActiveControl = null;
            this.DataTypeTile.Location = new System.Drawing.Point(4, 217);
            this.DataTypeTile.Name = "DataTypeTile";
            this.DataTypeTile.Size = new System.Drawing.Size(120, 100);
            this.DataTypeTile.TabIndex = 5;
            this.DataTypeTile.Text = "DataType";
            this.DataTypeTile.UseSelectable = true;
            this.DataTypeTile.Click += new System.EventHandler(this.DataTypeTile_Click);
            // 
            // interfaceTile
            // 
            this.interfaceTile.ActiveControl = null;
            this.interfaceTile.Location = new System.Drawing.Point(4, 111);
            this.interfaceTile.Name = "interfaceTile";
            this.interfaceTile.Size = new System.Drawing.Size(120, 100);
            this.interfaceTile.TabIndex = 4;
            this.interfaceTile.Text = "Interface";
            this.interfaceTile.UseSelectable = true;
            this.interfaceTile.Click += new System.EventHandler(this.interfaceTile_Click);
            // 
            // PrimitiveTile
            // 
            this.PrimitiveTile.ActiveControl = null;
            this.PrimitiveTile.Location = new System.Drawing.Point(130, 217);
            this.PrimitiveTile.Name = "PrimitiveTile";
            this.PrimitiveTile.Size = new System.Drawing.Size(120, 100);
            this.PrimitiveTile.TabIndex = 3;
            this.PrimitiveTile.Text = "Primitive";
            this.PrimitiveTile.UseSelectable = true;
            this.PrimitiveTile.Click += new System.EventHandler(this.PrimitiveTile_Click);
            // 
            // SimpleClasTile
            // 
            this.SimpleClasTile.ActiveControl = null;
            this.SimpleClasTile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SimpleClasTile.Location = new System.Drawing.Point(5, 5);
            this.SimpleClasTile.Name = "SimpleClasTile";
            this.SimpleClasTile.Size = new System.Drawing.Size(120, 100);
            this.SimpleClasTile.TabIndex = 2;
            this.SimpleClasTile.Text = "Simple Class";
            this.SimpleClasTile.Theme = MetroFramework.MetroThemeStyle.Light;
            this.SimpleClasTile.UseSelectable = true;
            this.SimpleClasTile.Click += new System.EventHandler(this.metroTile1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.metroTile18);
            this.panel1.Controls.Add(this.metroTile17);
            this.panel1.Controls.Add(this.metroTile16);
            this.panel1.Controls.Add(this.metroTile15);
            this.panel1.Controls.Add(this.metroTile14);
            this.panel1.Controls.Add(this.metroTile13);
            this.panel1.Controls.Add(this.metroTile11);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(867, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(158, 650);
            this.panel1.TabIndex = 6;
            // 
            // metroTile18
            // 
            this.metroTile18.ActiveControl = null;
            this.metroTile18.Location = new System.Drawing.Point(5, 374);
            this.metroTile18.Name = "metroTile18";
            this.metroTile18.Size = new System.Drawing.Size(150, 50);
            this.metroTile18.TabIndex = 8;
            this.metroTile18.Text = "metroTile18";
            this.metroTile18.UseSelectable = true;
            // 
            // metroTile17
            // 
            this.metroTile17.ActiveControl = null;
            this.metroTile17.Location = new System.Drawing.Point(5, 321);
            this.metroTile17.Name = "metroTile17";
            this.metroTile17.Size = new System.Drawing.Size(150, 50);
            this.metroTile17.TabIndex = 7;
            this.metroTile17.Text = "metroTile17";
            this.metroTile17.UseSelectable = true;
            // 
            // metroTile16
            // 
            this.metroTile16.ActiveControl = null;
            this.metroTile16.Location = new System.Drawing.Point(5, 268);
            this.metroTile16.Name = "metroTile16";
            this.metroTile16.Size = new System.Drawing.Size(150, 50);
            this.metroTile16.TabIndex = 6;
            this.metroTile16.Text = "metroTile16";
            this.metroTile16.UseSelectable = true;
            // 
            // metroTile15
            // 
            this.metroTile15.ActiveControl = null;
            this.metroTile15.Location = new System.Drawing.Point(5, 215);
            this.metroTile15.Name = "metroTile15";
            this.metroTile15.Size = new System.Drawing.Size(150, 50);
            this.metroTile15.TabIndex = 5;
            this.metroTile15.Text = "metroTile15";
            this.metroTile15.UseSelectable = true;
            // 
            // metroTile14
            // 
            this.metroTile14.ActiveControl = null;
            this.metroTile14.Location = new System.Drawing.Point(5, 162);
            this.metroTile14.Name = "metroTile14";
            this.metroTile14.Size = new System.Drawing.Size(150, 50);
            this.metroTile14.TabIndex = 4;
            this.metroTile14.Text = "metroTile14";
            this.metroTile14.UseSelectable = true;
            // 
            // metroTile13
            // 
            this.metroTile13.ActiveControl = null;
            this.metroTile13.Location = new System.Drawing.Point(5, 109);
            this.metroTile13.Name = "metroTile13";
            this.metroTile13.Size = new System.Drawing.Size(150, 50);
            this.metroTile13.TabIndex = 3;
            this.metroTile13.Text = "metroTile13";
            this.metroTile13.UseSelectable = true;
            // 
            // metroTile11
            // 
            this.metroTile11.ActiveControl = null;
            this.metroTile11.Location = new System.Drawing.Point(5, 56);
            this.metroTile11.Name = "metroTile11";
            this.metroTile11.Size = new System.Drawing.Size(150, 50);
            this.metroTile11.TabIndex = 2;
            this.metroTile11.Text = "metroTile11";
            this.metroTile11.UseSelectable = true;
            // 
            // MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(1025, 650);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.metroPanelClasses);
            this.IsMdiContainer = true;
            this.Name = "MainScreen";
            this.Text = "Diagram to Code";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainScreen_Load);
            this.metroPanelClasses.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanelClasses;
        private MetroFramework.Controls.MetroTile SimpleClasTile;
        private MetroFramework.Controls.MetroTile ObjectTile;
        private MetroFramework.Controls.MetroTile StereotypeTile;
        private MetroFramework.Controls.MetroTile DataTypeTile;
        private MetroFramework.Controls.MetroTile PrimitiveTile;
        private MetroFramework.Controls.MetroTile EnumTile;
        private MetroFramework.Controls.MetroTile PackageTile;
        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroTile metroTile18;
        private MetroFramework.Controls.MetroTile metroTile17;
        private MetroFramework.Controls.MetroTile metroTile16;
        private MetroFramework.Controls.MetroTile metroTile15;
        private MetroFramework.Controls.MetroTile metroTile14;
        private MetroFramework.Controls.MetroTile metroTile13;
        private MetroFramework.Controls.MetroTile metroTile11;
        private MetroFramework.Controls.MetroTile interfaceTile;

    }
}

