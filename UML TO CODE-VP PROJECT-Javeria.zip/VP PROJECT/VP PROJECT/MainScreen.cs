﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace VP_PROJECT
{
    public partial class MainScreen : Form
    {
       

        Form fm = new Form();
        ClassName cn = new ClassName();
        public MainScreen()
        {
            InitializeComponent();

        }
       
        private void MainScreen_Load(object sender, EventArgs e)
        {

        }

        private void metroTile1_Click(object sender, EventArgs e)
        {
            ClassName fm = new ClassName();
            MainScreen mn = new MainScreen();
            fm.MdiParent = this;
            fm.Show();

        }

        private void metroTile2_Click(object sender, EventArgs e)
        {
           
        }

        private void interfaceTile_Click(object sender, EventArgs e)
        {
            ClassName fm = new ClassName();
            fm.MdiParent = this;
            fm.Text = "<<i>>";
            fm.Show();
        }

        private void EnumTile_Click(object sender, EventArgs e)
        {

            ClassName fm = new ClassName();
            fm.MdiParent = this;
            fm.Text = "<<e>>";
            fm.Show();
        }

        private void DataTypeTile_Click(object sender, EventArgs e)
        {
            ClassName fm = new ClassName();
            fm.MdiParent = this;
            fm.Text = "<<dt>>";
            fm.Show();
        }

        private void ObjectTile_Click(object sender, EventArgs e)
        {
            ClassName fm = new ClassName();
            fm.MdiParent = this;
            fm.Text = "Object";
            fm.Show();
        }

        private void PrimitiveTile_Click(object sender, EventArgs e)
        {
            ClassName fm = new ClassName();
            fm.MdiParent = this;
            fm.Text = "<<p>>";
            fm.Show();
        }

        private void StereotypeTile_Click(object sender, EventArgs e)
        {
            ClassName fm = new ClassName();
            fm.MdiParent = this;
            fm.Text = "<<s>>";
            
            fm.Show();

        }
    }
}


